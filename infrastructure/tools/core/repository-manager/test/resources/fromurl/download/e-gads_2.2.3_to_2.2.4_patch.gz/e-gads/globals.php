<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: globals.php
	# Version: 16 August 2004
	# Author: Calvin Martini
	# Description: Global definitions

	#
	# >>>START USER EDITABLE PARAMETERS<<<
	#
	$dbhostname = "localhost";					# MySQL host IP or hostname
	$dbusername = "egads";							# MySQL egads user ID
	$dbpassword = "CHANGE_ME";					# MySQL egads user's password 
	$dbname = "egads";									# MySQL database name
	$locale = "locales/ca_en-fr";				# Absolute or relative path to active locale, no trailing slash
	$error_url = "login.php";						# Page users are directed to when an error occurs
	$sr_notify = "your.email@host.org";		# Email addresses for new search report notification
	$admin_email = "your.email@host.org";	# Application administrator email address
	$mail_footer = "\n======\nThis is an automated notification email from the E-GADS Database System."; # Notification email footer
	define("ENABLEMAP", FALSE);					# Set to TRUE to enable map report function - see README_Install.txt for important details before enabling this feature!
	$mapData = "/home/httpd/html/e-gads/maps/ca";					# Absolute or relative path to active map data set (if installed) - no trailing slash
	$logfile = "data/e-gads.log";				# Absolute or relative path (including file name) to application log file
	$debug_addr="192\.168.*";						# IP addresses or perl regex pattern to display debug info footer to on display page
	$serverURL = "https://sardat.homeunix.org/e-gads";	# Server URL, no trailing slash. e.g. http://www.myserver.net, https://www.secure.org/egads, etc. Used to register SOAP server for E-GADS Ops module
	#
	# >>>END USER EDITABLE PARAMETERS<<<
	#

	# Include common code
	require ("common.php");

?>
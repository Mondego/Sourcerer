# MySQL Input Script to convert e-gads Database Structure from v2.23 to v2.24 format
#
#
#  For MySQL Server
#  05 June 2004


# Select Database
USE egads;

# Add variable field support

CREATE TABLE IF NOT EXISTS types_vars (
	id_record int(11) NOT NULL auto_increment,
	id_type Int,
	enabled tinyint(3) unsigned default NULL,
	field_desc1 varchar(20),
	field_desc2 varchar(20),
	field_desc3 varchar(20),
	field_desc4 varchar(20),
	field_desc5 varchar(20),
	PRIMARY KEY (id_record)
) TYPE=MyISAM PACK_KEYS=1;
ALTER TABLE members ADD OptField1 varchar(30);
ALTER TABLE members ADD OptField2 varchar(30);
ALTER TABLE members ADD OptField3 varchar(30);
ALTER TABLE members ADD OptField4 varchar(30);
ALTER TABLE members ADD OptField5 varchar(30);

# Drop unused columns

# Update field names and add new fields

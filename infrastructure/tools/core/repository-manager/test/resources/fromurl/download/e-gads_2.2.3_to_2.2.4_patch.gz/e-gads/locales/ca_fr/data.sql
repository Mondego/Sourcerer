# E-GADS! Electronic Ground Search and Rescue Administrative Database
# Copyright (C) 2003 Calvin Martini

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

# E-GADS! Application Data load
# Version 29 April 2004

USE egads;

# Create test user accounts
INSERT INTO users (email,full_name,user_id,password,flag_diralt,flag_admin,when_expires,auth_province) VALUES
('your.email@host.org','E-GADS Administrator','admin','AGr6Sr3RFjWCY','1','1','2010-12-31','9999');

# Set up team access, User 2
# 999 in id_teams means access applies for ALL TEAMS
INSERT INTO team_access (id_users,id_teams,access_searches,access_members,access_training,access_certifications) VALUES 
('1','9999','128','128','128','128');

INSERT INTO types_cert_agencies (
	agency_desc1,
	agency_desc2,
	agency_desc3,
	agency_desc4,
	agency_desc5,
	agency_address,
	agency_city,
	agency_province,
	agency_pcode,
	agency_phone,
	agency_fax,
	agency_email,
	agency_website
) VALUES 
('Red Cross','','','','','','','2','','','','',''),
('DND','','','','','','','2','','','','',''),
('Saint John Ambulance','','','','','','','2','','','','','');
	
INSERT INTO types_events (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Perdue','','','','','Sujet ne sait pas ou elle se trouve','','','',''),
('Manquante','','','','Personne n\'est pas perdue, mais amis/famille pensent qu\'elle est','','','',''),
('Evidence','','','','Recherche demandee par agence policiere pour retrouver autre que des personnes perdues/manquantes.','','','',''),
('Sauvetage','','','','','','','','',''),
('Meeting','Reunion','','','','','','','',''),
('Recovery','Recovery','','','','','','','','');

INSERT INTO types_cal_events (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Reunion','','','','','','','','',''),
('Formation','','','','','','','','',''),
('Sociable','','','','','','','','',''),
('Information','','','','','','','','',''),
('Vacances','','','','','','','','','');

INSERT INTO types_equipment (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Inconnu','','','','','','','','',''),
('Trop','','','','','','','','',''),
('Bonne','','','','','','','','',''),
('Mal','','','','','','','','','');

INSERT INTO types_experience (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Inconnu','','','','','','','','',''),
('Expert','','','','','','','','',''),
('Advanced','','','','','','','','',''),
('Intermediate','','','','','','','','',''),
('Beginner','','','','','','','','',''),
('Aucun','','','','','','','','','');

INSERT INTO types_position (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Directeur Recherche','','','','','','','',''),
('Chef De Section OPs','','','','','','','',''),
('Planification','','','','','','','',''),
('Officier','','','','','','','',''),
('Op�rateur De Transmissions','','','','','','','',''),
('Officier Mat�riel','','','','','','','',''),
('Officier Logistics','','','','','','','',''),
('Sitstat/Restat','','','','','','','',''),
('Finances','','','','','','','','');

INSERT INTO types_contacts (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Maison','','','','','','','',''),
('Bureau','','','','','','','',''),
('Pager','','','','','','','',''),
('Cellulaire','','','','','','','',''),
('E-Mail','','','','','','','',''),
('Fax','','','','','','','','');
	
INSERT INTO types_reason (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Avalanche','','','','','','','',''),
('Obscurit�','','','','','','','',''),
('�garement','','','','','','','',''),
('Bris de glace','','','','','','','',''),
('M�t�o','','','','','','','',''),
('Catastrophe naturelle','','','','','','','',''),
('Autre cause environnementale','','','','','','','',''),
('Chute','','','','','','','',''),
('Noyade','','','','','','','',''),
('Chavirage','','','','','','','',''),
('�chouement','','','','','','','',''),
('Submersion','','','','','','','',''),
('Surestimation des capacit�s','','','','','','','',''),
('Autre cause li�e � l\'activit�','','','','','','','',''),
('Violence','','','','','','','',''),
('Mauvaise communication','','','','','','','',''),
('Alcool','','','','','','','',''),
('Raison m�dicale','','','','','','','',''),
('R�action allergique','','','','','','','',''),
('Arrêt cardiaque','','','','','','','',''),
('D�pression','','','','','','','',''),
('Blessure','','','','','','','',''),
('S�paration','','','','','','','',''),
('Fausse alarme','','','','','','','',''),
('Fatigue','','','','','','','',''),
('Incident caus� par un animal','','','','','','','',''),
('Suicide ou tentative','','','','','','','',''),
('Panne m�canique','','','','','','','',''),
('Panne d=essence','','','','','','','',''),
('Coinc�','','','','','','','',''),
('Laiss� en plan','','','','','','','',''),
('Autre','','','','','','','',''),
('Inconnue','','','','','','','','');

INSERT INTO types_resources (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Personnel form�','','','','','','','',''),
('Personnel non form�','','','','','','','',''),
('Police','','','','','','','',''),
('Militaires','','','','','','','',''),
('Personnel m�dical','','','','','','','',''),
('Services sociaux','','','','','','','',''),
('Chien','','','','','','','',''),
('FLIR','','','','','','','',''),
('A�roglisseur','','','','','','','',''),
('V�hicule terrestre','','','','','','','',''),
('Navire','','','','','','','',''),
('A�ronef � voilure fixe','','','','','','','',''),
('H�licopt�re','','','','','','','',''),
('Mâchoires de survie','','','','','','','',''),
('Civi�re ambulante','','','','','','','','');

INSERT INTO types_techniques (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Recherche Rapide','','','','','','','',''),
('Separation Criticale','','','','','','','',''),
('Recherche de nuit','','','','','','','',''),
('Recherches en ligne droite','','','','','','','',''),
('Isolement','','','','','','','',''),
('Attraction','','','','','','','',''),
('D�ploiement � quadrillage ouvert','','','','','','','',''),
('Ratissage','','','','','','','',''),
('Chiens travaillant en d�tection','','','','','','','',''),
('Chiens travaillant en d�pistage','','','','','','','',''),
('Pistage','','','','','','','',''),
('Recherche a�rienne','','','','','','','',''),
('Recherche maritime','','','','','','','',''),
('Recherche en cas d\'avalanche','','','','','','','',''),
('Contour','','','','','','','','');

INSERT INTO types_province (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5,extent) VALUES 
('Terre Neuve et du Labrador','','','','','','','','',''),
('Nouveau Brunswick','','','','','','','','',''),
('l\'�le-du-Prince-�douard','','','','','','','','',''),
('Qu�bec','','','','','','','','',''),
('Ontario','','','','','','','','',''),
('Nouvelle-�cosse','','','','','','','','',''),
('Manitoba','','','','','','','','',''),
('Saskatchewan','','','','','','','','',''),
('Alberta','','','','','','','','',''),
('Columbie Britanique','','','','','','','','',''),
('Maine, Etats-Unis','','','','','','','','',''),
('Yukon','','','','','','','','',''),
('Territoires du Nord-Ouest','','','','','','','','',''),
('Nunavut','','','','','','','','','');

INSERT INTO types_activity (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Randonn�e','','','','','','','',''),
('Camping','','','','','','','',''),
('Pêche','','','','','','','',''),
('Chasse','','','','','','','',''),
('Cueillette','','','','','','','',''),
('Navigation','','','','','','','',''),
('Escalade','','','','','','','',''),
('Natation','','','','','','','',''),
('Ski de fond','','','','','','','',''),
('Ski alpin','','','','','','','',''),
('Planche � neige','','','','','','','',''),
('Errance','','','','','','','',''),
('Fugue','','','','','','','',''),
('Activit� professionnelle','','','','','','','',''),
('Autre','','','','','','','',''),
('Inconnue','','','','','','','','');

INSERT INTO types_environment (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Urbain/Banlieue','','','','','','','',''),
('Plat','','','','','','','',''),
('C�teux','','','','','','','',''),
('Accident��','','','','','','','',''),
('Milieu marin','','','','','','','',''),
('Montagneux','','','','','','','',''),
('Rivi�re/Lac','','','','','','','',''),
('Eaux vives','','','','','','','',''),
('Inondation/Syst�me de contr�le','','','','','','','',''),
('Autre','','','','','','','',''),
('Inconnu','','','','','','','','');

INSERT INTO types_weather (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Inconnu','','','','','','','',''),
('Temps froid','','','','','','','',''),
('Temps sec/Normal','','','','','','','',''),
('Pluie/Pluie vergla�ante','','','','','','','',''),
('Neige','','','','','','','',''),
('Vente','','','','','','','',''),
('Autre','','','','','','','',''),
('Brouillard','','','','','','','','');

INSERT INTO types_outcome (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Inconnu','','','','','','','',''),
('Trouv� en vie','','','','','','','',''),
('Trouv� mort','','','','','','','',''),
('Non trouv�','','','','','','','',''),
('Fausse alarme','','','','','','','',''),
('Sujet s&acute;en sort seul','','','','','','','','');

INSERT INTO types_condition (type1,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) VALUES 
('Inconnu','','','','','','','',''),
('Bon �tat','','','','','','','',''),
('Malade','','','','','','','',''),
('Hypothermique','','','','','','','',''),
('Choc','','','','','','','',''),
('�vanouissement','','','','','','','',''),
('Blessures mineures','','','','','','','',''),
('Blessures graves','','','','','','','',''),
('Autre','','','','','','','','');


<?php var_dump($HTTP_GET_VARS); echo "test=$test"; ?>

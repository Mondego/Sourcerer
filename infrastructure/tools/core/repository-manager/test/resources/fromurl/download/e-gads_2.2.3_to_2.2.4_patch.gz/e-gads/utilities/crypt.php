<?php

	# Program: cyrpt.php
	# Version: 1.0, 8 November 2001
	# Author: Calvin Martini
	# Description: This script encrypts a user provded string


echo "<form method=GET action=crypt.php ENCTYPE=\"application/x-www-form-urlencoded\" name=MForm>
		<p>Input string: <input type=text name=instring size=50 value=\"$instring\"></p>
		<p>Encrypted string: <input type=text name=string size=50 value=\"".($instring ? crypt($instring,'AG') : "")."\" readonly></p>
		<input type=submit name=action value=Encrypt>
		</form>";

?>

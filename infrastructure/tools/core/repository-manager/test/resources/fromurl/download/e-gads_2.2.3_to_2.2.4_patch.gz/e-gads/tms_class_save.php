<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: class_save.php
	# Version: 27 August 2004
	# Author: Calvin Martini
	# Description: Save class record.

	session_start(); 

	# Set client variables
	$client_vars=array(
		'action',
		'mode',
		'dd_e_d_end',
		'dd_e_d_start',
		'e_id',
		'e_count',
		'e_iselect',
		'e_location',
		'e_mark',
		'e_module',
		'e_province',
		'e_select',
		'e_students',
		'e_t_end',
		'e_t_start',
		'e_team',
		'mm_e_d_end',
		'mm_e_d_start',
		's_id',
		'yyyy_e_d_end',
		'yyyy_e_d_start'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	require("globals.php");

	connect_db();

	# Set the user's team access arrays
	list($a_search, $a_memb, $a_train, $a_cert, $a_all_teams, $a_team, $a_team_name)=team_access("access_training");

	if ($action == $l['cancel']){
		header("Location: display.php".SIDPRINT."\n\n");
		exit;
	}elseif($action == $l['delete'] && (max($a_train) >= 4 || $a_admin == 1)){
		$query ="DELETE FROM attend_classes WHERE id_classes='$s_id'";
		$result = mysql_query($query) or die ($l['query_failed'].":$query");
		$query ="DELETE FROM classes WHERE id_record='$s_id'";
		$result = mysql_query($query) or die ($l['query_failed'].":$query");
		
		# Redirect the browser
		header("Location: display.php".SIDPRINT."\n\n");
		exit;
	}
	# Check to ensure proper access level to edit record
	if (($e_team==9999 && $a_all_teams!=1) || (max($a_train)<2) || session_is_registered("id_user")==FALSE) {
		fail_access($_SERVER['QUERY_STRING']);
	}


	# Save Record
	if ($mode == "update"){

		$query="UPDATE classes SET
					id_module='$e_module',
					id_members='$id_recno',
					location='$e_location',
					id_province='$e_province',
					id_teams='$e_team',
					when_start='$yyyy_e_d_start-$mm_e_d_start-$dd_e_d_start $e_t_start',
					when_end='$yyyy_e_d_end-$mm_e_d_end-$dd_e_d_end $e_t_end'
					WHERE id_record='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

	}elseif ($mode == "new"){
		
			$query="INSERT INTO classes (
						id_module,
						id_members,
						location,
						id_province,
						id_teams,
						when_start,
						when_end
					) VALUES (
						'$e_module',
						'$id_recno',
						'$e_location',
						'$e_province',
						'$e_team',
						'$yyyy_e_d_start-$mm_e_d_start-$dd_e_d_start $e_t_start',
						'$yyyy_e_d_end-$mm_e_d_end-$dd_e_d_end $e_t_end'
					)";
			$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
			$s_id = mysql_insert_id();

	}else{
		bad_access($_SERVER['QUERY_STRING']);
	}
		
	# Process Students
	if ($e_students){
		# Students are being modified using search interface

		# First, delete all of the student records for this clasee
		$query="DELETE FROM attend_classes WHERE id_classes='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

		$query="INSERT INTO attend_classes (id_classes, id_members, grade, instructor) VALUES ";
		$data = explode(";",$e_students);
		$count=1;
		foreach ($data as $line){
			list($line_id[$count],$line_instructor[$count],$line_grade[$count]) = explode(",",$line);
			if ($line_id[$count]){$query.="('$s_id','$line_id[$count]','$line_grade[$count]','$line_instructor[$count]')".($count==count($data)-1 ? "":",");}
			$count++;
		}

		$query=rtrim($query,",");
		
		if ($count>0){$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");}

	}elseif(count($e_select)){
		# Students are being modified using single form

		# First, delete all of the student records for this clasee
		$query="DELETE FROM attend_classes WHERE id_classes='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
		
		# Now add the modified records
		$query="INSERT INTO attend_classes (id_classes, id_members, grade, instructor) VALUES ";
		$count=0;
		foreach ($e_count as $i){
			if ($e_select[$i]){
				$query.="('$s_id','$e_id[$i]','$e_mark[$i]','".($e_iselect[$i] ? "1" : "0")."'),";
				$count++;
			}
		}
		$query=rtrim($query,",");
		if ($count>0){$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");}
	}

	if ($action == $l['copy']){
		$original_id = $s_id;

		$query = "SELECT * FROM classes WHERE id_record='$original_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
		if (mysql_num_rows($result)) {

			# Copy the class record
			$r = mysql_fetch_array($result);
			$query = "INSERT INTO classes (
						id_module,
						id_members,
						location,
						id_province,
						id_teams,
						when_start,
						when_end
					) VALUES (
						'".$r['id_module']."',
						'$id_recno',
						'".$r['location']."',
						'".$r['id_province']."',
						'".$r['id_teams']."',
						'".$r['when_start']."',
						'".$r['when_end']."'
					)";
			$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
			$s_id = mysql_insert_id();

			# Copy the student records
			$query2 = "SELECT * FROM attend_classes WHERE id_classes = '$original_id'";
			$result2 = mysql_query($query2) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query2");
			if (mysql_num_rows($result2)) {
				$query3="INSERT INTO attend_classes (id_classes, id_members, grade, instructor) VALUES ";
				while ($r2 = mysql_fetch_array($result2)) {
					$query3.="('$s_id','".$r2['id_members']."','".$r2['grade']."','".$r2['instructor']."'),";
					$count++;
				}
				$query3=rtrim($query3,",");
				$result3 = mysql_query($query3) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query3");
			}
		}

		# Now return to edit the newly copied class	
		header("Location: tms_class_edit.php?mode=update&s_id=$s_id".SIDAND."\n\n");
		exit;
	}

	logit($logfile,"250\t$mode class ".($s_id ? "$s_id " : "")."by $id_user.");
	header("Location: display.php".SIDPRINT."\n\n");
	exit;

?>
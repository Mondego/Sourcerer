#!/usr/bin/perl

# E-GADS! Electronic Ground Search and Rescue Administrative Database
# Copyright (C) 2003 Calvin Martini

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

use Socket;

# MAIN

        $_url					= "http://www.host.org/apps/ip_link.cgi";
        $pattern			= "<a href=\"http://142.166";

        &get_page;

        if ($page_content =~ /$pattern/){
					# Pattern was matched
					print "$page_content\n\nPATTERN $pattern FOUND!";
				}else{
					# Pattern was not matched
					print "$page_content\n\nPattern $pattern was not found.\n\n";
				}

sub get_page{

				# Extract just the hostname from a complete URL. eg. http://www.com/dir becomes www.com
                $server = $_url;
                $server =~ s/.*\/\///;
                $server =~ s/\/.*//;

        # default port
                $port = "80";

        # get absolute path and document. eg. http://www.com/dir becomes /dir
                $abs_path = $_url;
                $abs_path =~ s/.*\/\///;
                $abs_path =~ s/.*?\//\//;

                $server_addr =(gethostbyname($server))[4];
                $server_struct = pack("S n a4 x8", AF_INET, $port, $server_addr);
                $proto = (getprotobyname('tcp'))[2];
                socket(MYSOCK, PF_INET, SOCK_STREAM, $proto)|| die "Failed to initialize socket: $!\n";
                connect(MYSOCK, $server_struct) || die "Failed to connect() to server: $!\n";
                select(MYSOCK);
                $| = 1;
                select(STDOUT);
                print MYSOCK "GET $abs_path HTTP/1.1\nHost: $server\n\n";

                while (<MYSOCK>) {
                        $page_content = $page_content.$_;
                }
                close(MYSOCK);
}


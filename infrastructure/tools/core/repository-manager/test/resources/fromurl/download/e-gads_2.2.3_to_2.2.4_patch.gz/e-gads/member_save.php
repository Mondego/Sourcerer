<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: member_save.php
	# Version: 05 August 2004
	# Author: Calvin Martini
	# Description: Save member record.

	session_start(); 

	require("globals.php");
	connect_db();

	# Set client variables
	$client_vars=array(
		'action','s_id','t_id','mode',
		'FlagState',
		'e_name_first','e_name_last','e_name_middle','e_name_common',
		'e_address_street','e_id_address_province','e_address_pcode','e_address_city',
		'e_health','e_member_id',
		'yyyy_e_date_applied','mm_e_date_applied','dd_e_date_applied',
		'yyyy_e_date_approved','mm_e_date_approved','dd_e_date_approved',
		'yyyy_e_date_joined','mm_e_date_joined','dd_e_date_joined',
		'yyyy_e_date_expires','mm_e_date_expires','dd_e_date_expires',
		'e_title','e_name_next_of_kin','e_occupation',
		'yyyy_e_date_of_birth', 'mm_e_date_of_birth','dd_e_date_of_birth',
		'e_flag_director','e_flag_alternate','e_flag_emergency','e_flag_admin','e_flag_inactive',
		'e_notes','e_display_priority',
		'e_phone_work','e_phone_home','e_phone_cell','e_phone_fax','e_phone_pager','e_phone_other','e_email',
		'e_team_province',
		'e_id_teams',
		'e_certification','e_agency',
		'yyyy_e_certified','mm_e_certified','dd_e_certified',
		'yyyy_e_expires','mm_e_expires','dd_e_expires',
		'yyyy_e_date_test','mm_e_date_test','dd_e_date_test',
		'yyyy_e_search1','mm_e_search1','dd_e_search1','e_mock1',
		'yyyy_e_search2','mm_e_search2','dd_e_search2','e_mock2',
		'e_opt1','e_opt2','e_opt3','e_opt4','e_opt5',
		'e_cert_changed'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}
	
	# Set the user's team access arrays
	list($a_search, $a_memb, $a_train, $a_cert, $a_all_teams, $a_team, $a_team_name)=team_access("access_members");

	# Check to ensure proper access level to edit record
	if (max($a_memb) < 2 || session_is_registered("id_user")==FALSE) {
		fail_access($_SERVER['QUERY_STRING']);
	}

	if ($action == $l[cancel]){
		header("Location: display.php".SIDPRINT."\n\n");
		exit;
	}elseif($action == $l[delete] && max($a_memb) >= 4){
		if ($FlagState){logit("data/e_flag.txt","$s_id\t$e_name_first $e_name_last\tdeleted.");}
		$query ="DELETE FROM attend_persons WHERE id_members='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		$query ="DELETE FROM attend_classes WHERE id_members='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		$query ="DELETE FROM certifications WHERE id_members='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		$query ="DELETE FROM teams_members WHERE id_members='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		$query ="DELETE FROM members WHERE id_record='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		logit($logfile,"227\tDelete member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
		header("Location: display.php".SIDPRINT."\n\n");
		exit;
	}
	
	if ($mode == "update"){

		$query="UPDATE members SET
					id_users='$id_recno',
					name_first='$e_name_first',
					name_last='$e_name_last',
					name_middle='$e_name_middle',
					name_common='$e_name_common',
					address_street='$e_address_street',
					address_city='$e_address_city',
					id_address_province='$e_id_address_province',
					address_pcode='$e_address_pcode',
					health='$e_health',
					member_id='$e_member_id',
					date_applied='$yyyy_e_date_applied-$mm_e_date_applied-$dd_e_date_applied',
					date_approved='$yyyy_e_date_approved-$mm_e_date_approved-$dd_e_date_approved',
					date_joined='$yyyy_e_date_joined-$mm_e_date_joined-$dd_e_date_joined',
					date_expires='$yyyy_e_date_expires-$mm_e_date_expires-$dd_e_date_expires',
					title='$e_title',
					name_next_of_kin='$e_name_next_of_kin',
					occupation='$e_occupation',
					date_of_birth='$yyyy_e_date_of_birth-$mm_e_date_of_birth-$dd_e_date_of_birth',
					flag_director='$e_flag_director',
					flag_alternate='$e_flag_alternate',
					flag_emergency='$e_flag_emergency',
					flag_admin='$e_flag_admin',
					flag_inactive='$e_flag_inactive',
					notes='$e_notes',
					display_priority='$e_display_priority',
					phone_work='$e_phone_work',
					phone_home='$e_phone_home',
					phone_cell='$e_phone_cell',
					phone_fax='$e_phone_fax',
					phone_pager='$e_phone_pager',
					phone_other='$e_phone_other',
					email='$e_email',
					OptField1='$e_opt1',
					OptField2='$e_opt2',
					OptField3='$e_opt3',
					OptField4='$e_opt4',
					OptField5='$e_opt5',
					team_province='$e_team_province'
					WHERE id_record='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		logit($logfile,"222\tUpdate member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
		if ($FlagState){logit("data/e_flag.txt","$s_id\t$e_name_first $e_name_last\tupdated. ".$FlagState);}

	}elseif ($mode == "new"){
		$query="INSERT INTO members (
					id_users,
					name_first,
					name_last,
					name_middle,
					name_common,
					address_street,
					address_city,
					id_address_province,
					address_pcode,
					health,
					member_id,
					date_applied,
					date_approved,
					date_joined,
					date_expires,
					title,
					name_next_of_kin,
					occupation,
					date_of_birth,
					flag_director,
					flag_alternate,
					flag_emergency,
					flag_admin,
					flag_inactive,
					notes,
					display_priority,
					phone_work,
					phone_home,
					phone_cell,
					phone_fax,
					phone_pager,
					phone_other,
					email,
					OptField1,
					OptField2,
					OptField3,
					OptField4,
					OptField5,
					team_province
				) VALUES (
					'$id_recno',
					'$e_name_first',
					'$e_name_last',
					'$e_name_middle',
					'$e_name_common',
					'$e_address_street',
					'$e_address_city',
					'$e_id_address_province',
					'$e_address_pcode',
					'$e_health',
					'$e_member_id',
					'$yyyy_e_date_applied-$mm_e_date_applied-$dd_e_date_applied',
					'$yyyy_e_date_approved-$mm_e_date_approved-$dd_e_date_approved',
					'$yyyy_e_date_joined-$mm_e_date_joined-$dd_e_date_joined',
					'$yyyy_e_date_expires-$mm_e_date_expires-$dd_e_date_expires',
					'$e_title',
					'$e_name_next_of_kin',
					'$e_occupation',
					'$yyyy_e_date_of_birth-$mm_e_date_of_birth-$dd_e_date_of_birth',
					'$e_flag_director',
					'$e_flag_alternate',
					'$e_flag_emergency',
					'$e_flag_admin',
					'$e_flag_inactive',
					'$e_notes',
					'$e_display_priority',
					'$e_phone_work',
					'$e_phone_home',
					'$e_phone_cell',
					'$e_phone_fax',
					'$e_phone_pager',
					'$e_phone_other',
					'$e_email',
					'$e_opt1',
					'$e_opt2',
					'$e_opt3',
					'$e_opt4',
					'$e_opt5',
					'$e_team_province'
				)";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		$s_id = mysql_insert_id() ;
		logit($logfile,"223\tNew member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
		if ($FlagState){logit("data/e_flag.txt","$s_id\t$e_name_first $e_name_last\tadded.");}

	}
	
	if ($mode =="update" || $mode == "new"){

		# Process Team Selections
		$query="DELETE FROM teams_members WHERE id_members='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
		
		$query="INSERT INTO teams_members (id_members,id_teams) VALUES";
		$count=count($e_id_teams);
		for ($i=0; $i<$count; $i++){
			$t_id = $e_id_teams[$i];
			$query.="('$s_id','".$e_id_teams[$i]."')".($i==($count-1)? "":",");
		}
		if ($i>0){$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");}

		# Process certifications
		if ($action == $l[add] && $e_certification){

			$query = "SELECT flag_cuser FROM types_certifications WHERE id_record='$e_certification'";
			connect_db();
			$result = mysql_query($query) or die ($l['query_failed'].":$query");
			if (mysql_num_rows($result)) {
				$r = mysql_fetch_array($result);
				$e_flag_cuser = $r['flag_cuser'];
			}


			$query="INSERT INTO certifications (
					id_users,
					id_members,
					id_types_certifications,
					id_certifying_agency,
					".($e_flag_cuser == 0 || ($a_cert[$t_id] == 128 ||($mode == "new" && max($a_cert) == 128)) ? "date_certified,date_expires,date_test," : "")."
					id_instructor,
					date_search1,
					flag_search1,
					date_search2,
					flag_search2
				) VALUES (
					'$id_recno',
					'$s_id',
					'$e_certification',
					'$e_agency',
					".($e_flag_cuser == 0 || ($a_cert[$t_id] == 128 ||($mode == "new" && max($a_cert) == 128)) ? "'$yyyy_e_certified-$mm_e_certified-$dd_e_certified','$yyyy_e_expires-$mm_e_expires-$dd_e_expires','$yyyy_e_date_test-$mm_e_date_test-$dd_e_date_test'," : "")."
					'',
					'$yyyy_e_search1-$mm_e_search1-$dd_e_search1',
					'$e_mock1',
					'$yyyy_e_search2-$mm_e_search2-$dd_e_search2',
					'$e_mock2'
				)";
			$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");

			$record = mysql_insert_id();

			if (($e_flag_cuser == 0 || ($a_cert[$t_id] == 128 ||($mode == "new" && max($a_cert) == 128))) && $e_cert_changed == "T"){
				logit($logfile,"225\tAdd certified (date and/or expiry) certification $record $cert_name for member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
			}else{
				logit($logfile,"224\tAdd uncertified certification $record $cert_name for member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
			}
			header("Location: member_edit.php?mode=update&s_id=$s_id&t_id=$t_id".SIDAND."\n\n");
			exit;

		}elseif($action == $l[add] && ! $e_certification){
			header("Location: member_edit.php?mode=update&s_id=$s_id&t_id=$t_id".SIDAND."\n\n");
			exit;
		}

		$delete = ereg_replace("\s","+",$l[delete_selected]);
		if ($action == $l[delete] && (max($a_memb) >= 4 || max($a_cert) >= 4)){
			$query = "SELECT id_record AS record FROM certifications	WHERE id_members='$s_id'";
			$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query");
			if (mysql_num_rows($result)) {
				while ($r = mysql_fetch_array($result)) {
					if ($ebox[$r[record]]){
						$query2 ="DELETE FROM certifications WHERE id_record='$r[record]'";
						$result2 = mysql_query($query2) or die (mysql_errno().": ".mysql_error()."<BR><BR>$l[query_failed]:$query2");
					}
				}
			}
			logit($logfile,"226\tDelete certification $record $cert_name for member ".($s_id ? "$s_id " : "").($e_name_first ? "$e_name_first " : "").($e_name_last ? "$e_name_last " : "")."by $id_user.");
			header("Location: member_edit.php?mode=update".($s_id ? "&s_id=$s_id" : "").($t_id ? "&t_id=$t_id" : "")." \n\n");
			exit;
		}

	}else{
		bad_access($_SERVER['QUERY_STRING']);
	}

	header("Location: display.php".SIDPRINT."\n\n");
	exit;

?>
<?php
# E-GADS! Electronic Ground Search and Rescue Administrative Database
# Copyright (C) 2003 Calvin Martini

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

# Program: class_login.php
# Version: 11 August 2004
# Author: Calvin Martini
# Description: Login class for E-GADS

class login{
	var $user;
	var $password;
	var $id_recno;
	var $dbuser;
	var $dbpassword;
	var $dbhost;
	var $dbname;
	var $status = array(0,0,0,0);
	var $conn;
	var $query;
	var $result;
	var $r;
	var $a_search;
	var $a_memb;
	var $a_cert;
	var $a_train;
	var $a_all_teams;
	var $a_team;
	var $a_team_name;

	function login (){
        print( "Use the static functions: login::authenticate()" );
	}

	function authenticate($dbhost,$dbuser,$dbpassword,$dbname,$user='',$password='') {
		login::db_connect($dbhost,$dbuser,$dbpassword,$dbname);
		$query = "SELECT users.* FROM users WHERE user_id='$user'";
		$result = mysql_query($query);
		// Test for user
		if ( mysql_num_rows($result) != 0 ) {
			$r = mysql_fetch_array($result);
			// Test for bad password
			if ( crypt($password,$r['password']) == $r['password'] ) {
				// Test for expired account
				if ( $r['when_expires'] && (strtotime($r['when_expires']) >= time())) {
					$status = array($r['id_record'],$r['flag_diralt'],$r['flag_admin'],($r['auth_province'] == 9999 ? -1 : $r['auth_province']));
				}else{
					$status = array(-3,0,0,0); // Account Expired
				}
			}else{
				$status = array(-2,0,0,0); // Bad password
			}
		}else{
			$status = array(-1,0,0,0); // User not found
		}
		return $status;
	}

	function team_access($field){
		#/////////////////////////////////////////////////////////////////////////////////// 
		#/// FUNCTION:
		#/// Reads team_access, determines security access
		#/// 
		#/// PARAMETERS:
		#/// $field							database field in table users to compare for single team access
		#/// $name							base field name
		#/// $in_date						current date (yyyy-mm-dd)
		#/// $yy_past,$yy_future		years to subtract and add to current year to get year range
		#/// 
		#/// RETURNS: 
		#/// Arrays for a_search, a_memb, a_cert, a_train, a_exp
		#///////////////////////////////////////////////////////////////////////////////////

		# Get the number of teams
		$query = "SELECT COUNT(*) AS count_teams FROM teams";
		$result = mysql_query($query);
		$num_rows = mysql_num_rows($result);
		if ($num_rows) { 
			$r = mysql_fetch_array($result);
			$count_teams = $r['count_teams'];

			# Initialize the access arrays
			$a_search = array_pad(array(), $count_teams+1, "0");
			$a_memb = array_pad(array(), $count_teams+1, "0");
			$a_cert = array_pad(array(), $count_teams+1, "0");
			$a_train = array_pad(array(), $count_teams+1, "0");
			$a_all_teams=0;
			$a_team=0;
			$a_team_name = NULL;

			# Set team access
			$query = "SELECT team_access.*
						FROM team_access
						WHERE team_access.id_users='$this->id_recno'";
			$result = mysql_query($query);
			$num_rows = mysql_num_rows($result);
			if ($num_rows) {
				while ($r = mysql_fetch_array($result)) {
					if ($r['id_teams']=="9999"){
						$a_all_teams = 1;
						$a_team = -1;

						if ($this->a_prov==9999){
							$a_search = array_pad(array(), $count_teams+1, $r['access_searches']);	$a_search[0]=0;			
							$a_memb = array_pad(array(), $count_teams+1, $r['access_members']);	$a_memb[0]=0;				
							$a_cert = array_pad(array(), $count_teams+1, $r['access_certifications']);	$a_cert[0]=0;				
							$a_train = array_pad(array(), $count_teams+1, $r['access_training']);	$a_train[0]=0;				
						}else{
							$query2="SELECT id_record FROM teams WHERE id_address_province='$this->a_prov'";
							$result2 = mysql_query($query2);
							while ($r2 = mysql_fetch_array($result2)) {
								$a_search[$r2['id_record']]=$r['access_searches'];
								$a_memb[$r2['id_record']]=$r['access_members'];
								$a_cert[$r2['id_record']]=$r['access_certifications'];
								$a_train[$r2['id_record']]=$r['access_training'];
							}
						}

						$a_search[9999]=$r['access_searches'];
						$a_memb[9999]=$r['access_members'];
						$a_cert[9999]=$r['access_certifications'];
						$a_train[9999]=$r['access_training'];

						break 1;
					}else{
						$a_search[$r['id_teams']]=$r['access_searches'];
						$a_memb[$r['id_teams']]=$r['access_members'];
						$a_cert[$r['id_teams']]=$r['access_certifications'];
						$a_train[$r['id_teams']]=$r['access_training'];
					}
				}

				# Determine single team access
				if ($a_all_teams==0){
					$query = "SELECT teams.id_record, teams.team_name
						FROM teams 
						LEFT JOIN team_access ON team_access.id_teams=teams.id_record  
						WHERE team_access.$field>=2 AND team_access.id_users='$this->id_recno'
						GROUP BY teams.id_record";
					$result = mysql_query($query);
					if (mysql_num_rows($result) == 1){
						$r = mysql_fetch_array($result);
							$a_team = $r['id_record'];
							$a_team_name = $r['team_name'];
					}
				}
			}

		}
		# Return the access arrays
		return array ($a_search, $a_memb, $a_train, $a_cert, $a_all_teams, $a_team, $a_team_name);
	}

	function db_connect($dbhost,$dbuser,$dbpassword,$dbname) {
		$conn = mysql_connect($dbhost,$dbuser,$dbpassword);
		mysql_select_db($dbname,$conn);
	}



}

?>
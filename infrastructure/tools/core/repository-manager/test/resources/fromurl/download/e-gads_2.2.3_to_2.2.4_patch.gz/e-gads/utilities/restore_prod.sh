# E-GADS! Electronic Ground Search and Rescue Administrative Database
# Copyright (C) 2003 Calvin Martini

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

rm --force /var/lib/mysql/e-gads/*
cp --force /home/backup/backup_e-gads/e-gads/* /var/lib/mysql/e-gads
mysqladmin -p flush-tables
myisamchk -r /var/lib/mysql/e-gads/*.MYI
chown mysql:mysql /var/lib/mysql/e-gads/*

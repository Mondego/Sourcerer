Change History
==============

E-GADS! Electronic Ground Search and Rescue Administrative Database
Copyright (C) 2004 Calvin Martini

2004-09-11 Version 2.2.4
========================
Bugs Fixed:
- base_summary.php: corrected problem with membership count being innacurate.
- base_summary.php: fixed filtering for direct calls.
- Corrected Canadian French language strings to match with user and admin manual translations.
- sr_save.php: Fixed file number reference in notification email.
- sr_save.php: Total hours weren't being saved.
- sr_save.php: Subjects weren't being saved.
- tms_class_edit.php: Fixed problem where province and team selection wouldn't initiate rest of form.
- sr_edit.php, tms_class_edit.php and tms_class_choose.php: RFE977615 Filter out inactive members for attendees list when editing
- sr_subject_edit.php: FIxed problem where only first three columns would display on some browsers due to unmatched </big> tag
- admin_save.php: Province wasn't retained for new user record when adding team access.
- tms_course_select.php: Using search feature caused edit mode to be lost resulting in no record to edit.
- tms_class_edit.php: Delete button wasn't showing for users with "all teams" access.
- Added support for mapserver on Microsoft Windows platforms

Other:
- Added French documentation
- RFE 953171 - Variable field support. Now up to 5 optional fields for the member form can be added through the administrative interface.
- Added classes for new XML data transfer capability
- RFE 1002013 - Added copy class feature. When editing an existing class, pressing the copy button will save the record, create a copy then return to edit the new class.

2004-05-27 Version 2.2.3
========================
Bugs Fixed:
- Fixed bug 960280: Setting register_globals=Off in php.ini configuration causes E-GADS! to lose data.
- sr_edit.php: Added access level check for delete button on update.
- member_edit.php: Added access level check for delete button on update.
- member_save.php: Fixed problem where system would return user to display.php instead of member-edit.php when adding a certification with no type selected.
- tms_course_edit.php: Fixed problem where adding a module wouldn't save the tcourse team selection and generated a security alert.
- tms_course_edit.php: Corrected problem where team wouldn't be selected when updating records if user had r/w access to two or more teams, but not admin access.
- tms_course_edit.php: Added access level check for delete button on update.
- tms_class_save.php: Added access level check for delete button on update.
- tms_module_edit.php: Corrected access level check for delete button on update.
- cert_edit.php: Corrected access level check for delete button on update.
- member_edit.php: fixed problem where team select box displayed mysql resource warnings for line 365 for users with access to more than one team (but not all teams).
- resetpw2.php: Corrected problem that prevented cancel button from working.

Other:
- Changed documentation license from GNU Public License (GPL) to GNU Free Documentation License (GFDL).
- Moved common code out of globals.php and into common.php to separate program code from user-definable variables - makes upgrading easier.
- cert_edit.php: Added validation of team selection on submit. Prevents entry of certification levels with team of "None".
- event_edit.php: Added validation of team selection on submit.
- login2.php: Now set team filter for report display upon login.
- lib_headers.php: Added ability to substitute a URL or non-email http address for the footer contact webmaster link based on the admin_email value in globals.php.
 
2004-05-19 Version 2.2.2
========================
Bugs Fixed:
- patch 956082: convert_v2.11_to_v2.20 duplicate drop statement in line 23 removed. Caused script to break.
- patch 955888: rosa.jar missing from package. Affected map display only.
- patch 955885: event report displays multiple copies of same record. display.php updated by adding GROUP By to SELECT statement.


2004-05-08 Version 2.2
======================
New Features:
- Feature: event_save outputs flag file for use with db_event_cal_mail.
- Hard coded flag_dir - was unnecessary to have as user definable.
- Converted numerous scripts for enhanced language support.
- Added documenation directory containing User and Administrator manuals in html format.

Bugs Fixed:
- Bug fix: 938660 - Event report edit links for user with all_teams but only read level access
- Security: Changed HTTP method from GET to POST in login and pass_save to prevent password from being logged in web server log
- Added password reset feature.
- Added flag_cuser (removed sc_record) - more flexible way to define certification user on per cert basis

2004-04-19 Version 2.1.1 sp1
============================
- Fixed critical bugs in tms_class_edit.php (hash in string, line 354) and tms_class_save.php (removed id_recno from client vars list).

2004-04-12 Version 2.1.1
========================
- Added flag_op to table teams to allow application to distibguish between administrative teams (associations, government, etc.) and operational teams (those which respond to emergencies). This flag is used by the new display script to properly filter non-emergency contacts from the emergency members report.
- Corrected members reports to properly display members belonging to more than one team.

2004-03-28 Version 2.1.0
========================
This is a fairly extensive re-write to permit operation with the php directive Register_Globals set to off. This is a major security enhancement as it reduces the likelihood of a user passing extraneous variables to the application.

BUGS FIXED:
===========
2004-03-27 Modified display.php to properly display events filtered on a single province for 
all teams.
2004-03-28 Revised login2.php to re-enable account lockout features.

FEATURES ADDED:
===============
2004-03-28 Modified most scripts to enable use with php directive register_globals set to off.
2004-03-28 Added debug_addr variable to globabls.php. This can be used to specify IP addresses (or a php regular expression) to which debug information should be shown for the display.php script (at the bottom of the output). This information can be useful when debugging the scripts (for developers).

2003-09-12 Version 2.0.2
========================
No enhancements or bug fixes in this release. 

The only change is in the packaging and installation instructions. Starting with version 2.0.2 the software will be distributed in two versions; with and without map display. The non-map version will be the version most users will want since the map installation works only on UNIX, is complex and contains only Canadian data. The non-map package is considerably smaller.

2003-09-01 Version 2.0.1
========================

Changes made to overcome installation problems (with sincerest apologies to those who suffered needlessly!).

BUGS FIXED:
===========
2003-09-01 Modified setup.sql to correct missing fields in types_province definition
2003-09-01 Changed database name in setup.sql, data.sql and globals.php to eliminate hyphenated name: e-gads became egads
2003-09-01 Changed admin user in data.sql
2003-09-01 Changed scripturl variable to error_url in globals.php and lib_security.php to more accurately reflect purpose
2003-09-01 Revised installation guide to reflect new changes.

FEATURES ADDED:
===============
2003-09-01 Added constant ENABLEMAP to permit enabling/disabling of the map display functions. This permits vastly simplified installations for those not willing to tackle the MapServer configuration. Particularly valuable to those being co-hosted at an ISP or who are running systems outside Canada (the GIS data provided currently only covers Canada).


2003-08-30 Version 2.0.0
========================

This release is the first made publicly available. It is the result of two years effort.


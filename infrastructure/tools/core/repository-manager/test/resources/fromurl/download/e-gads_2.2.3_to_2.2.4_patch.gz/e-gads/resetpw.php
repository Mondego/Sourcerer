<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: resetpw.php
	# Version: 09 July 2004
	# Author: Calvin Martini
	# Description: This script outputs the entry form for user-initiated password resets.

	session_start(); 
	# Set client variables

	$client_vars=array(
		'language'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	require("globals.php");

	connect_db();

	head("login");

	echo "<center>
			<img src=\"$locale/images/logo".$_SESSION['lang'].".jpg\"><br>
			<h1 class=LoginH>".$l['reset_password']."</h1>
			<p>
			".$l['reset_msg1']."<br>
			<strong>".$l['reset_msg2']."</strong>
			</p><br>
			<form method=\"POST\" action=\"resetpw2.php\">
			<input type=\"hidden\" name=\"language\" value=\"$lang\">
			<TABLE class=LoginTbl WIDTH=400 BORDER=0 CELLPADDING=8 CELLSPACING=0>
			<TR>
				<TD class=LoginTd align=right>
					<font class=LoginInpH>".$l['userid'].":</font>
				</TD>
				<TD class=LoginTd>
					<input class=LoginInp type=\"text\" name=\"reset_id\"><br>
				</TD>
			</TR>
			<TR>
				<TD class=LoginTd colspan=2 align=center>
					<BR>
						<input class=BodyBut type=submit name=action value=\"".$l['reset_password']."\">".($mode=="update" ? "<input class=BodyBut type=submit name=action value=\"".$l['delete']."\">" : "")."
						<input class=BodyBut type=submit name=action value=".$l['cancel'].">
				</TD>
			</TR>
			</TABLE>					
			</form>
			
			</TABLE>
			<br><br>";

	echo "</center>
			<br><br>\n";
	foot();

?>

<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: login.php
	# Version: 09 July 2004
	# Author: Calvin Martini
	# Description: primary login screen to application.

	session_start();

	# If a session is already registered for this user, destroy it
	if (isset($_SESSION['id_user'])){
		$_SESSION = array();
		session_destroy();
	}

	require("globals.php");

	head("login");

	echo "<center>
			<img src=\"$locale/images/logo".$_SESSION['lang'].".jpg\"><br>
			<small><em>v".EGADSVER."</em></small>
			<h1 class=LoginH>".$l['login']."</h1>
			<p>
			".$l['login_msg1']."<br>
			<strong>".$l['login_msg2']."</strong>
			</p><br>
			<form method=\"POST\" action=\"login2.php\">
			<input type=\"hidden\" name=\"language\" value=\"$lang\">
			<TABLE class=LoginTbl WIDTH=400 BORDER=0 CELLPADDING=8 CELLSPACING=0>
			<TR>
				<TD class=LoginTd align=right>
					<font class=LoginInpH>".$l['userid'].":</font>
				</TD>
				<TD class=LoginTd>
					<input class=LoginInp type=\"text\" name=\"id_user\"><br>
				</TD>
			</TR>
			<TR>
				<TD class=LoginTd align=right>
					<font class=LoginInpH>".$l['password'].":</font>
				</TD>
				<TD class=LoginTd>
					<input class=LoginInp type=\"password\" name=\"id_password\">
				</TD>
			</TR>
			<TR>
				<TD class=LoginTd colspan=2 align=center>
					<BR>
					<input class=LoginBut type=\"submit\" value=\"".$l['login']."\">
				</TD>
			</TR>
			</TABLE>
			</form>

			</TABLE>
			<br><br>";
	if ($maxLang > 1){
		for ($x = 1; $x <= $maxLang; $x++){
			if ($x != $lang){
				echo "<a class=\"navbar2\" href=\"login.php?language=$x\">".$l['lang'.$x]."</a>".($x <$maxLang ? "&nbsp;&nbsp;" : "");
			}
		}
		echo "<br>";
	}

	echo "<p class=BodyTxt><a class=\"navbar2\" href=\"resetpw.php?language=$lang\">".$l['forgot_password']."</a></p>";

	echo "</center>
			<br><br>\n";
	foot();
	logit($logfile,"201\tLogin access.");

?>
<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003,2004 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: transfer_server.php
	# Version: 16 August 2004
	# Author: Calvin Martini
	# Description: SOAP server for requests from E-GADS Ops module

	// Include the SOAP Server
	require_once('SOAP/Server.php');

	// Include E-GADS globals
	require("globals.php");

	// Set the time limit to permit large data sets - Won't work if PHP's safe mode is on. Also, set max_execution_time = 300 in php.ini
	set_time_limit(300);

	// Start the SOAP server
	require_once('classes/class_transfer_server.php');
	$t_server = new transfer($dbhostname,$dbusername,$dbpassword,$dbname,"$serverURL#transfer");
?>
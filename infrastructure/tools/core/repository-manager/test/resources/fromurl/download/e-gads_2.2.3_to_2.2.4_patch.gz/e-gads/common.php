<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: common.php
	# Version: 8 September 2004
	# Author: Calvin Martini
	# Description: Common code

	# Set Session variables
	if(isset($_SESSION['id_user'])){
		$URI_current=$_SESSION['URI_current'];
		$URI_previous=$_SESSION['URI_previous'];
		$a_admin=$_SESSION['a_admin'];
		$a_diralt=$_SESSION['a_diralt'];
		$a_prov=$_SESSION['a_prov'];
		$a_province=$_SESSION['a_province'];
		$a_provName=array("",$_SESSION['a_provName1'],$_SESSION['a_provName2'],$_SESSION['a_provName3'],$_SESSION['a_provName4'],$_SESSION['a_provName5']);
		$id_password=$_SESSION['id_password'];
		$id_recno=$_SESSION['id_recno'];
		$id_user=$_SESSION['id_user'];
		$lang=$_SESSION['lang'];
		$s_filter=$_SESSION['s_filter'];
		$s_period=$_SESSION['s_period'];
		$s_period_2=$_SESSION['s_period_2'];
		$s_popplace=$_SESSION['s_popplace'];
		$s_ppage=$_SESSION['s_ppage'];
		$s_province=$_SESSION['s_province'];
		$s_province_2=$_SESSION['s_province_2'];
		$s_rail=$_SESSION['s_rail'];
		$s_report=$_SESSION['s_report'];
		$s_report_2=$_SESSION['s_report_2'];
		$s_road=$_SESSION['s_road'];
		$s_search_scope=$_SESSION['s_search_scope'];
		$s_search_scope_2=$_SESSION['s_search_scope_2'];
		$s_teams=$_SESSION['s_teams'];
		$sa_filter=$_SESSION['sa_filter'];
		$sa_report=$_SESSION['sa_report'];
		$t_filter=$_SESSION['t_filter'];
		$t_period=$_SESSION['t_period'];
		$t_province2=$_SESSION['t_province'];
		$t_province=$_SESSION['t_province'];
		$t_report=$_SESSION['t_report'];
		$t_search_scope=$_SESSION['t_search_scope'];
		$t_team2=$_SESSION['t_team2'];
	}
	require ("$locale/locale.php");

	# Include language definitions based on session variable lang
	if (isset($_REQUEST['language']) && $_REQUEST['language'] > 0 && $_REQUEST['language'] <= $maxLang){
		$lang = $_REQUEST['language'];
		$_SESSION['lang'] = $lang;
	}elseif($_SESSION['lang'] > 0){
		$lang = $_SESSION['lang'];
	}else{
		$lang = 1;
		$_SESSION['lang'] = $lang;
	}
	require ("$locale/lang$lang.php");

	# Constants
	define("EGADSVER", "2.2.4");
	define("SIDHIDDEN", (SID ? "<input type=hidden name=PHPSESSID value=" .session_id().">" : ""));
	define("SIDAND", (SID ? "&".SID : ""));
	define("SIDPRINT", (SID ? "?".SID : ""));

	# Include common libraries
	require ("lib_headers.php");
	require ("lib_fileio.php");
	require ("lib_security.php");
	require ("lib_html.php");

	# seed with microseconds since last "whole" second
	srand ((float) microtime() * 1000000);

?>
#!/bin/sh
#
# E-GADS! Electronic Ground Search and Rescue Administrative Database
# Copyright (C) 2003 Calvin Martini

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# FTP File with backups
#
#
## User definable parameters
g_file="file to transfer"
g_dir="path to file to transfer"
g_host="ftp host"
g_user="ftp user"
g_pwd="ftp password"
g_target="target filesystem path"
g_progpath="/usr/local/scripts"
g_list="your.email@host.org"
## End user definable parameters


g_date=$(date +%y%m%d%H%M)

cd $g_target
ftp -n $g_host <<-EOF
user $g_user $g_pwd
cd $g_dir
bin
get $g_file
bye
EOF

if [ -f $g_target/$g_file ] ; then
        mv $g_target/$g_file $g_target/$g_file.$g_date
	echo "Contacts Backup for $(date)" | $g_progpath/biabam $g_target/$g_file.$g_date -s "AUTOMAIL: E-GADS! Contacts System" $g_list
fi

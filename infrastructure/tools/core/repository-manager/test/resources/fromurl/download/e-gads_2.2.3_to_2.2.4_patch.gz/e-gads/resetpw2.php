<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: resetpw2.php
	# Version: 09 July 2004
	# Author: Calvin Martini
	# Description: This script resets a user's password and emails it to them.

	# Set client variables
	$client_vars=array('reset_id'); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	session_start(); 

	# Set client variables
	$client_vars=array(
		'language',
		'action',
		'reset_id'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	require("globals.php");

	connect_db();

	if ($action == $l['cancel']){
		header("Location: login.php?language=$lang".SIDPRINT." \n\n");
		exit;
	}

	head("login");

	echo "<center><img src=\"$locale/images/logo".$_SESSION['lang'].".jpg\"><br>
			<h1 class=LoginH>".$l['reset_password']."</h1>";

	# Get user's name and email
	$query="SELECT id_record, full_name, email FROM users WHERE user_id='$reset_id'";
	$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
	if (mysql_num_rows($result)) {

		$r = mysql_fetch_array($result);
		$email = $r['email'];
		$user_record = $r['id_record'];
		$name = $r['full_name'];

		# Generate a random password

		## Set the random id length 
		$reset_passwd_length = 10; 

		## Generate a random password, encrypt it and store it in $reset_passwd 
		$reset_passwd = crypt(uniqid(rand(),1)); 

		## Remove slashes 
		$reset_passwd = strip_tags(stripslashes($reset_passwd)); 

		## Remove . or / and reverse the string 
		$reset_passwd = str_replace(".","",$reset_passwd); 
		$reset_passwd = strrev(str_replace("/","",$reset_passwd)); 
		$reset_passwd = substr($reset_passwd,0,$reset_passwd_length); 

		## Reset the user's password
		$query="UPDATE users SET password='".crypt($reset_passwd,'AG')."' WHERE id_record='$user_record'";
		$result = mysql_query($query) or die ($l['query_failed'].":$query");

		# Mail new/update notification message
		if (!empty($admin_email)) {
			mail($email, $l['reset_password'] , $l['password']." = $reset_passwd".$mail_footer,
				"From: $admin_email\nReply-To: $admin_email\nX-Mailer: PHP/" . phpversion());
		}      

		echo "<p class=BodyTxt>".$l['password_reset']."</p>";
		logit($logfile,"203\tPassword reset for $reset_id.");
		# Display login link and footer
		echo "<p class=BodyTxt><a class=\"navbar2\" href=\"login.php\">".$l['login']."</a></p>";

	}else{
		# Nothing matched the query
		echo "<p class=BodyTxt>".$l['invalid_user']."</p>";
		logit($logfile,"506\tPassword reset for user $reset_id failed - invalid user ID.");
		# Display login link and footer
		echo "<p class=BodyTxt><a class=\"navbar2\" href=\"resetpw.php\">".$l['reset_password']."</a></p>";
	}


	echo "</center>
			<br><br>\n";
	foot();
	
?>
	
<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: admin_save.php
	# Version: 22 August 2004
	# Author: Calvin Martini
	# Description: Save type records.

	session_start(); 

	# Set client variables
	$client_vars=array(
		'action',
		'agency_address',
		'agency_city',
		'agency_desc1',
		'agency_desc2',
		'agency_desc3',
		'agency_desc4',
		'agency_desc5',
		'agency_email',
		'agency_fax',
		'agency_pcode',
		'agency_phone',
		'agency_province',
		'agency_website',
		'assoc1',
		'assoc2',
		'assoc3',
		'assoc4',
		'assoc5',
		'dd_when_expires',
		'desc_type1',
		'desc_type2',
		'desc_type3',
		'desc_type4',
		'desc_type5',
		'e_a_certifications',
		'e_a_members',
		'e_a_searches',
		'e_a_training',
		'e_access_certifications',
		'e_access_members',
		'e_access_searches',
		'e_access_training',
		'e_id_record',
		'e_id_teams',
		'e_passwd',
		'e_province',
		'e_repasswd',
		'e_team',
		'email',
		'enabled',
		'expires',
		'extent',
		'field_desc1',
		'field_desc2',
		'field_desc3',
		'field_desc4',
		'field_desc5',
		'flag_admin',
		'flag_diralt',
		'full_name',
		'id_members',
		'id_province',
		'id_teams',
		'id_type',
		'lat_coords',
		'logo_file',
		'long_coords',
		'mm_when_expires',
		'mode',
		'phone',
		'prefix',
		's_id',
		'sa_report',
		'scope',
		'type',
		'type1',
		'type2',
		'type3',
		'type4',
		'type5',
		'user_id',
		'yyyy_when_expires'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	require("globals.php");
	connect_db();

	# Check to ensure proper access level to edit record
	if ($a_admin == 0 || isset($_SESSION["id_user"])==FALSE) {
		fail_access($_SERVER['QUERY_STRING']);
	}

	if ($action == $l['cancel'] || $scope == $l['cancel']){
		header("Location: admin_display.php".SIDPRINT." \n\n");
		exit;
	}elseif($action == $l['delete'] && $a_admin){
		$query ="DELETE FROM $sa_report WHERE id_record='$s_id'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

		if ($sa_report == "users"){
			$query ="DELETE FROM team_access WHERE id_users='$s_id'";
			$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
		}
		
		header("Location: admin_display.php".SIDPRINT." \n\n");
		exit;
	}
	
	if ($mode == "update"){
		switch (true) {

			case ($sa_report=="types_techniques" 
				|| $sa_report=="types_experience" 
				|| $sa_report=="types_equipment" 
				|| $sa_report=="types_events"
				|| $sa_report=="types_cal_events"
				|| $sa_report=="types_resources"
				|| $sa_report=="types_reason"
				|| $sa_report=="types_condition"
				|| $sa_report=="types_outcome"
				|| $sa_report=="types_environment"
				|| $sa_report=="types_position"
				|| $sa_report=="types_weather"
				|| $sa_report=="types_activity"
				|| $sa_report=="types_environment"
				|| $sa_report=="types_position"):

				$id_string = $type;

				$query="UPDATE $sa_report SET
					type1='$type1',
					type2='$type2',
					type3='$type3',
					type4='$type4',
					type5='$type5',
					desc_type1='$desc_type1',
					desc_type2='$desc_type2',
					desc_type3='$desc_type3',
					desc_type4='$desc_type4',
					desc_type5='$desc_type5'
					WHERE id_record='$s_id'";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
				
				break 1;

			case ($sa_report=="types_province"):

				$id_string = $type;

				$query="UPDATE $sa_report SET
					type1='$type1',
					type2='$type2',
					type3='$type3',
					type4='$type4',
					type5='$type5',
					desc_type1='$desc_type1',
					desc_type2='$desc_type2',
					desc_type3='$desc_type3',
					desc_type4='$desc_type4',
					desc_type5='$desc_type5',
					extent='$extent',
					assoc1='$assoc1',
					assoc2='$assoc2',
					assoc3='$assoc3',
					assoc4='$assoc4',
					assoc5='$assoc5',
					logo_file='$logo_file',
					prefix='$prefix'
					WHERE id_record='$s_id'";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
				
				break 1;

			case ($sa_report=="types_agencies" || $sa_report=="types_cert_agencies"):

				$id_string = $agency_desc;

				$query="UPDATE $sa_report SET
					agency_desc1='$agency_desc1',
					agency_desc2='$agency_desc2',
					agency_desc3='$agency_desc3',
					agency_desc4='$agency_desc4',
					agency_desc5='$agency_desc5',
					agency_address='$agency_address',
					agency_city='$agency_city',
					agency_province='$agency_province',
					agency_pcode='$agency_pcode',
					agency_phone='$agency_phone',
					agency_fax='$agency_fax',
					agency_email='$agency_email',
					agency_website='$agency_website'
					WHERE id_record='$s_id'";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_vars"):

				$id_string = $type;

				$query="UPDATE $sa_report SET
					id_type='$id_type',
					field_desc1='$field_desc1',
					field_desc2='$field_desc2',
					field_desc3='$field_desc3',
					field_desc4='$field_desc4',
					field_desc5='$field_desc5',
					enabled='$enabled'
					WHERE id_record='$s_id'";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_places"):

				$id_string = $type;

				$query="UPDATE $sa_report SET
					type='$type',
					lat_coords='$lat_coords',
					long_coords='$long_coords'
					WHERE id_record='$s_id'";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="users"):

				$id_string = $user_id;

				if ($e_passwd == $e_repasswd){

					$query="UPDATE $sa_report SET
						id_members='$id_members',
						full_name='$full_name',
						phone='$phone',
						email='$email',
						user_id='$user_id',
						".($e_passwd ? "password='".crypt($e_passwd,'AG')."'," : "")."
						when_expires='$yyyy_when_expires-$mm_when_expires-$dd_when_expires',
						flag_diralt='$flag_diralt',
						flag_admin='$flag_admin',
						auth_province='$e_province'
						WHERE id_record='$s_id'";
					$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				}else{

					bad_access($l['password_nomatch']);

				}

				# Process Team Access, Action=Save Selected
				if ($action==$l['save_updates']){

					# Now, add in the revised records
					$count=count($e_id_teams);
					for ($i=0; $i<$count; $i++){
						$query="UPDATE team_access 
								SET id_users='$s_id',
								id_teams='$e_id_teams[$i]',
								access_searches='$e_access_searches[$i]',
								access_members='$e_access_members[$i]',
								access_training='$e_access_training[$i]',
								access_certifications='$e_access_certifications[$i]'
								WHERE id_record='$e_id_record[$i]'";
						$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
						logit($logfile,"210\tUpdate team $e_id_teams[$i] for user $s_id by $id_user.");
					}
					header("Location: admin_edit.php?s_id=$s_id&mode=update".SIDAND."\n\n");
					exit;

				}

				# Process Team Access, Action=Add
				if ($action==$l['add'] && $e_team){
					$query="INSERT INTO team_access 
								(id_users,id_teams,access_searches,access_members,access_training,access_certifications) 
							  VALUES
							   ('$s_id','$e_team','$e_a_searches','$e_a_members','$e_a_training','$e_a_certifications')";
					$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
					logit($logfile,"211\tAdd team $e_team for user $s_id by $id_user.");
					header("Location: admin_edit.php?s_id=$s_id&mode=update".SIDAND."\n\n");
					exit;

				}
				
				# Process Team Access: Action=Delete Selected
				if ($action==$l['delete_selected']){
					$count=count($e_id_teams);
					for ($i=0; $i<$count; $i++){
						if ($e_box[$i]){
							$query="DELETE FROM team_access WHERE id_record='$e_id_record[$i]'";
							$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
							logit($logfile,"212\tDelete team $e_id_teams[$i] for user $s_id by $id_user.");
						}
					}
					header("Location: admin_edit.php?s_id=$s_id&mode=update".SIDAND."\n\n");
					exit;

				}
				
				
				break 1;

			default:
				echo "<p class=BodyTxt>".$l['no_results']."</p>";
				foot();
				exit;
		}

	}elseif ($mode == "new"){
		switch (true) {

			case ($sa_report=="types_techniques" 
				|| $sa_report=="types_experience" 
				|| $sa_report=="types_equipment" 
				|| $sa_report=="types_events"
				|| $sa_report=="types_cal_events"
				|| $sa_report=="types_resources"
				|| $sa_report=="types_reason"
				|| $sa_report=="types_condition"
				|| $sa_report=="types_outcome"
				|| $sa_report=="types_environment"
				|| $sa_report=="types_position"
				|| $sa_report=="types_weather"
				|| $sa_report=="types_activity"
				|| $sa_report=="types_environment"
				|| $sa_report=="types_position"):

				$id_string = $type;

				$query="INSERT INTO $sa_report (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5) 
					VALUES ('$type1','$type2','$type3','$type4','$type5','$desc_type1','$desc_type2','$desc_type3','$desc_type4','$desc_type5')";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_certifications"):
				$id_string = $type;

				$query="INSERT INTO $sa_report (type1,type2,type3,type4,type5,desc_type1,desc_type2,desc_type3,desc_type4,desc_type5,expires,id_teams,id_province) 
				VALUES ('$type1','$type2','$type3','$type4','$type5','$desc_type1','$desc_type2','$desc_type3','$desc_type4','$desc_type5','$expires','$id_teams','$id_province')";

				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_province"):

				$id_string = $type;

				$query="INSERT INTO $sa_report (
						type1,
						type2,
						type3,
						type4,
						type5,
						desc_type1,
						desc_type2,
						desc_type3,
						desc_type4,
						desc_type5,
						logo_file,
						assoc1,
						assoc2,
						assoc3,
						assoc4,
						assoc5,
						extent,
						prefix
					) VALUES (
						'$type1',
						'$type2',
						'$type3',
						'$type4',
						'$type5',
						'$desc_type1',
						'$desc_type2',
						'$desc_type3',
						'$desc_type4',
						'$desc_type5',
						'$logo_file',
						'$assoc1',
						'$assoc2',
						'$assoc3',
						'$assoc4',
						'$assoc5',
						'$extent',
						'$prefix'
					)";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			
			case ($sa_report=="types_agencies" || $sa_report=="types_cert_agencies"):

				$id_string = $agency_desc;

				$query="INSERT INTO $sa_report (
						agency_desc1,
						agency_desc2,
						agency_desc3,
						agency_desc4,
						agency_desc5,
						agency_address,
						agency_city,
						agency_province,
						agency_pcode,
						agency_phone,
						agency_fax,
						agency_email,
						agency_website
					) VALUES (
						'$agency_desc1',
						'$agency_desc2',
						'$agency_desc3',
						'$agency_desc4',
						'$agency_desc5',
						'$agency_address',
						'$agency_city',
						'$agency_province',
						'$agency_pcode',
						'$agency_phone',
						'$agency_fax',
						'$agency_email',
						'$agency_website'
					)";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_vars"):

				$id_string = $type;

				$query="INSERT INTO $sa_report (id_type,field_desc1,field_desc2,field_desc3,field_desc4,field_desc5,enabled) 
					VALUES ('$id_type','$field_desc1','$field_desc2','$field_desc3','$field_desc4','$field_desc5','$enabled')";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="types_places"):

				$id_string = $type;

				$query="INSERT INTO $sa_report (type,lat_coords,long_coords) 
					VALUES ('$type','$lat_coords','$long_coords')";
				$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

				break 1;

			case ($sa_report=="users"):

				$id_string = $user_id;
				
				if (!$user_id){
					head("admin_edit");
					bad_access($l['user_id_required']);
					exit;
				}
				
				if ($e_passwd == $e_repasswd){

					$query="INSERT INTO $sa_report (
							id_members,
							full_name,
							phone,
							email,
							user_id,
							".($e_passwd ? "password," : "")."
							when_expires,
							flag_diralt,
							flag_admin,
							auth_province
						) VALUES (
							'$id_members',
							'$full_name',
							'$phone',
							'$email',
							'$user_id',
							".($e_passwd ? "'".crypt($e_passwd,'AG')."'," : "")."
							'$yyyy_when_expires-$mm_when_expires-$dd_when_expires',
							'$flag_diralt',
							'$flag_admin',
							'$e_province'
						)";
					$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
					$s_id = mysql_insert_id();

				}else{

					head("admin_edit");
					bad_access($l['password_nomatch']);
					exit;

				}

				if ($action==$l['add'] && $e_team){
					$query="INSERT INTO team_access 
								(id_users,id_teams,access_searches,access_members,access_training,access_certifications) 
							  VALUES
							   ('$s_id','$e_team','$e_a_searches','$e_a_members','$e_a_training','$e_a_certifications')";
					$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");

					logit($logfile,"211\tAdd team $e_team for user $s_id by $id_user.");
					header("Location: admin_edit.php?s_id=$s_id&mode=update".SIDAND."\n\n");
					exit;

				}

				break 1;

			default:
				echo "<p class=BodyTxt>".$l['no_results']."</p>";
				foot();
				exit;
		}
				
	}else{
		fail_access($_SERVER['QUERY_STRING']);
	}

	logit($logfile,"213\t$mode $sa_report ".($s_id ? "$s_id " : "").($id_string ? "$id_string " : "")."by $id_user.");
	header("Location: admin_display.php".SIDPRINT."\n\n");
	exit;

?>

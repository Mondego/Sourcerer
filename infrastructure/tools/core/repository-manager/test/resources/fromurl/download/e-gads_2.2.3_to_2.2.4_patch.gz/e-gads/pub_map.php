<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# Program: pub_map.php
	# Version: 11 September 2004
	# Author: Calvin Martini
	# Description: Produces an html report containing a map of all searches

	# Set client variables
	$client_vars=array(
		's_province',
		's_report'
	); 
	foreach ($client_vars as $formvar){
	    $$formvar = (isset($_REQUEST[$formvar]))?$_REQUEST[$formvar]:NULL; 
	}

	require("globals.php");
	if (PHP_OS == "WINNT" || PHP_OS == "WIN32"){
      		dl("php_mapscript.dll");
    	}else{
      		dl("php_mapscript.so");
    	}
	if ($_REQUEST["MAP_NAME"])
		 $gpoMap = ms_newMapObj(strval($_REQUEST["MAP_NAME"]));
	else
		$gpoMap = ms_newMapObj("$mapData/map.map");
	require("lib_map.php");

	connect_db();

	head("public");

	# Set map display options
	$s_province=2;
	$layerCtl['road']=1;
	$layerCtl['rail']=1;
	$layerCtl['popplace']=1;
	$layerCtl['teams']=0;
	
	if ($s_province) {
		$query = "SELECT id_record, extent, type$lang AS province FROM types_province WHERE id_record='$s_province'";
		$result = mysql_query($query) or die (mysql_errno().": ".mysql_error()."<BR><BR>".$l['query_failed'].":$query");
		if (mysql_num_rows($result)) { 
			$r = mysql_fetch_array($result);
			$ViewRegion=$r['extent'];
		}
	}else{
		$ViewRegion="";
	}

	echo "<h2 class=normal>$l[$s_report]</h2>";

	require("map.phtml");

	foot();

?>

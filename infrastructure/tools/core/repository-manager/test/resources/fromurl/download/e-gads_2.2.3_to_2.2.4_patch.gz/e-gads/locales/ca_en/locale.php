<?php

	# E-GADS! Electronic Ground Search and Rescue Administrative Database
	# Copyright (C) 2003 Calvin Martini

	# This program is free software; you can redistribute it and/or
	# modify it under the terms of the GNU General Public License
	# as published by the Free Software Foundation; either version 2
	# of the License, or (at your option) any later version.

	# This program is distributed in the hope that it will be useful,
	# but WITHOUT ANY WARRANTY; without even the implied warranty of
	# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	# GNU General Public License for more details.

	# You should have received a copy of the GNU General Public License
	# along with this program; if not, write to the Free Software
	# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

	# E-GADS Locale file
	# ca_en Canadian English, generic locale for all provinces
	# Version: 07 July 2004

	$maxLang = 1; # number of language files for this locale

	# Graphic pixel widths for menu buttons for each language (on_[main,new,view,info,refresh].gif and off_[main,new,view,info,refresh].gif)
	$widthMain[1]="71";

	$widthNew[1]="68";

	$widthView[1]="72";

	$widthInfo[1]="145";

	$widthRefresh[1]="108";

?>

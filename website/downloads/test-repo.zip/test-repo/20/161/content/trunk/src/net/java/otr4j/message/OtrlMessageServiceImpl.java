package net.java.otr4j.message;

import java.util.List;

import net.java.otr4j.context.ConnContext;
import net.java.otr4j.tlv.OtrlTLV;
import net.java.otr4j.userstate.OtrlUserState;

public class OtrlMessageServiceImpl implements OtrlMessageService {

	@Override
	public void abortSMP(OtrlUserState us, ConnContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void disconnect(OtrlUserState us, String accountname,
			String protocol, String username) {
		// TODO Auto-generated method stub

	}

	@Override
	public String fragmentAndSend(ConnContext context, String message) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void initiateSMP(OtrlUserState us, ConnContext context,
			byte[] secret, String question) {
		// TODO Auto-generated method stub

	}

	@Override
	public int receiving(OtrlUserState us, String accountname, String protocol,
			String sender, String message, List<OtrlTLV> tlvs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void respondSMP(OtrlUserState us, ConnContext context, byte[] secret) {
		// TODO Auto-generated method stub

	}

	@Override
	public String sending(OtrlUserState us, String accountname,
			String protocol, String recipient, String message,
			List<OtrlTLV> tlvs) {
		// TODO Auto-generated method stub
		return null;
	}

}

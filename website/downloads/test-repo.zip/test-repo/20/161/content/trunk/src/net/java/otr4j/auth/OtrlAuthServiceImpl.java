package net.java.otr4j.auth;

import java.security.KeyPair;

import net.java.otr4j.privkey.OtrlPrivKey;

public class OtrlAuthServiceImpl implements OtrlAuthService {

	@Override
	public void clear(OtrlAuthInfo auth) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void create(OtrlAuthInfo auth) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleCommit(OtrlAuthInfo auth, String commitmsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleKey(OtrlAuthInfo auth, String keymsg, int havemsgp,
			OtrlPrivKey privkey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleRevealSig(OtrlAuthInfo auth, String revealmsg,
			int havemsgp, OtrlPrivKey privkey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleSignature(OtrlAuthInfo auth, String sigmsg, int havemsgp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleV1KeyExchange(OtrlAuthInfo auth, String keyexchmsg,
			int havemsgp, OtrlPrivKey privkey, KeyPair our_dh, int our_keyid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startV1(OtrlAuthInfo auth, KeyPair our_dh, int our_keyid,
			OtrlPrivKey privkey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startV2(OtrlAuthInfo auth) {
		// TODO Auto-generated method stub
		
	}

}

package net.java.otr4j.message;

import java.util.List;

import net.java.otr4j.context.ConnContext;
import net.java.otr4j.tlv.OtrlTLV;
import net.java.otr4j.userstate.OtrlUserState;

public interface OtrlMessageService {
	/*
	 * Handle a message about to be sent to the network. It is safe to pass all
	 * messages about to be sent to this routine. add_appdata is a function that
	 * will be called in the event that a new ConnContext is created. It will be
	 * passed the data that you supplied, as well as a pointer to the new
	 * ConnContext. You can use this to add application-specific information to
	 * the ConnContext using the "context->app" field, for example. If you don't
	 * need to do this, you can pass NULL for the last two arguments of
	 * otrl_message_sending.
	 * 
	 * tlvs is a chain of OtrlTLVs to append to the private message. It is
	 * usually correct to just pass NULL here.
	 * 
	 * If this routine returns non-zero, then the library tried to encrypt the
	 * message, but for some reason failed. DO NOT send the message in the clear
	 * in that case.
	 * 
	 * If *messagep gets set by the call to something non-NULL, then you should
	 * replace your message with the contents of *messagep, and send that
	 * instead. Call otrl_message_free(*messagep) when you're done with it.
	 */
	String sending(OtrlUserState us, String accountname,
			String protocol, String recipient, String message,
			List<OtrlTLV> tlvs);

	/*
	 * Handle a message just received from the network. It is safe to pass all
	 * received messages to this routine. add_appdata is a function that will be
	 * called in the event that a new ConnContext is created. It will be passed
	 * the data that you supplied, as well as a pointer to the new ConnContext.
	 * You can use this to add application-specific information to the
	 * ConnContext using the "context->app" field, for example. If you don't
	 * need to do this, you can pass NULL for the last two arguments of
	 * otrl_message_receiving.
	 * 
	 * If otrl_message_receiving returns 1, then the message you received was an
	 * internal protocol message, and no message should be delivered to the
	 * user.
	 * 
	 * If it returns 0, then check if *messagep was set to non-NULL. If so,
	 * replace the received message with the contents of *messagep, and deliver
	 * that to the user instead. You must call otrl_message_free(*messagep) when
	 * you're done with it. If tlvsp is non-NULL, *tlvsp will be set to a chain
	 * of any TLVs that were transmitted along with this message. You must call
	 * otrl_tlv_free(*tlvsp) when you're done with those.
	 * 
	 * If otrl_message_receiving returns 0 and *messagep is NULL, then this was
	 * an ordinary, non-OTR message, which should just be delivered to the user
	 * without modification.
	 */
	int receiving(OtrlUserState us, String accountname, String protocol,
			String sender, String message, List<OtrlTLV> tlvs);

	/*
	 * Send a message to the network, fragmenting first if necessary. All
	 * messages to be sent to the network should go through this method
	 * immediately before they are sent, ie after encryption.
	 */
	String fragmentAndSend(ConnContext context, String message);

	/*
	 * Put a connection into the PLAINTEXT state, first sending the other side a
	 * notice that we're doing so if we're currently ENCRYPTED, and we think
	 * he's logged in.
	 */
	void disconnect(OtrlUserState us, String accountname, String protocol,
			String username);

	/* Initiate the Socialist Millionaires' Protocol */
	void initiateSMP(OtrlUserState us, ConnContext context,
			byte[] secret, String question);

	/* Respond to a buddy initiating the Socialist Millionaires' Protocol */
	void respondSMP(OtrlUserState us, ConnContext context,
			byte[] secret);

	/*
	 * Abort the SMP. Called when an unexpected SMP message breaks the normal
	 * flow.
	 */
	void abortSMP(OtrlUserState us, ConnContext context);
}

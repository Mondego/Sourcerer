package net.java.otr4j.auth;

public class OtrlAuthInfo {

}

package net.java.otr4j.proto;

public interface OtrlMessageType {

}

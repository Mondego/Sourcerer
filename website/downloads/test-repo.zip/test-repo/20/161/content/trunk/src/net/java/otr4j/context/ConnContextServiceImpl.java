package net.java.otr4j.context;

import net.java.otr4j.userstate.OtrlUserState;

public class ConnContextServiceImpl implements ConnContextService {

	@Override
	public void contextForget(ConnContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextForgetAll(OtrlUserState us) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextForgetFingerprint(Fingerprint fprint,
			int and_maybe_context) {
		// TODO Auto-generated method stub

	}

	@Override
	public ConnContext find(OtrlUserState us, String user, String accountname,
			String protocol, Boolean add_if_missing) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Fingerprint findFingerprint(ConnContext context, byte[] fingerprint,
			Boolean add_if_missing) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void forceFinished(ConnContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void forcePlaintext(ConnContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setPresharedSecret(ConnContext context, byte[] secret) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTrust(Fingerprint fprint, String trust) {
		// TODO Auto-generated method stub

	}

}

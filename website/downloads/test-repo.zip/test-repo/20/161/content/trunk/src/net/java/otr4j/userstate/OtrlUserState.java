package net.java.otr4j.userstate;

import java.util.List;

import net.java.otr4j.context.ConnContext;
import net.java.otr4j.privkey.OtrlPrivKey;

public class OtrlUserState {
	List<ConnContext> contextList;
	List<OtrlPrivKey> privateKeys;
}

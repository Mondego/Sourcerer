package net.java.otr4j.auth;

import java.security.KeyPair;

import net.java.otr4j.privkey.OtrlPrivKey;

public interface OtrlAuthService {
	/*
	 * Initialize the fields of an OtrlAuthInfo (already allocated).
	 */
	void create(OtrlAuthInfo auth);

	/*
	 * Clear the fields of an OtrlAuthInfo (but leave it allocated).
	 */
	void clear(OtrlAuthInfo auth);

	/*
	 * Start a fresh AKE (version 2) using the given OtrlAuthInfo. Generate a
	 * fresh DH keypair to use. If no error is returned, the message to transmit
	 * will be contained in auth->lastauthmsg.
	 */
	void startV2(OtrlAuthInfo auth);

	/*
	 * Handle an incoming D-H Commit Message. If no error is returned, the
	 * message to send will be left in auth->lastauthmsg. Generate a fresh
	 * keypair to use.
	 */
	void handleCommit(OtrlAuthInfo auth, String commitmsg);

	/*
	 * Handle an incoming D-H Key Message. If no error is returned, and
	 * *havemsgp is 1, the message to sent will be left in auth->lastauthmsg.
	 * Use the given private authentication key to sign messages.
	 */
	void handleKey(OtrlAuthInfo auth, String keymsg, int havemsgp,
			OtrlPrivKey privkey);

	/*
	 * Handle an incoming Reveal Signature Message. If no error is returned, and
	 * *havemsgp is 1, the message to be sent will be left in auth->lastauthmsg.
	 * Use the given private authentication key to sign messages. Call the
	 * auth_succeeded callback if authentication is successful.
	 */
	void handleRevealSig(OtrlAuthInfo auth, String revealmsg, int havemsgp,
			OtrlPrivKey privkey);

	/*
	 * Handle an incoming Signature Message. If no error is returned, and
	 * *havemsgp is 1, the message to be sent will be left in auth->lastauthmsg.
	 * Call the auth_succeeded callback if authentication is successful.
	 */
	void handleSignature(OtrlAuthInfo auth, String sigmsg, int havemsgp);

	/*
	 * Start a fresh AKE (version 1) using the given OtrlAuthInfo. If our_dh is
	 * NULL, generate a fresh DH keypair to use. Otherwise, use a copy of the
	 * one passed (with the given keyid). Use the given private key to sign the
	 * message. If no error is returned, the message to transmit will be
	 * contained in auth->lastauthmsg.
	 */
	void startV1(OtrlAuthInfo auth, KeyPair our_dh, int our_keyid,
			OtrlPrivKey privkey);

	/*
	 * Handle an incoming v1 Key Exchange Message. If no error is returned, and
	 * *havemsgp is 1, the message to be sent will be left in auth->lastauthmsg.
	 * Use the given private authentication key to sign messages. Call the
	 * auth_secceeded callback if authentication is successful. If non-NULL, use
	 * a copy of the given D-H keypair, with the given keyid.
	 */
	void handleV1KeyExchange(OtrlAuthInfo auth, String keyexchmsg,
			int havemsgp, OtrlPrivKey privkey, KeyPair our_dh, int our_keyid);
}

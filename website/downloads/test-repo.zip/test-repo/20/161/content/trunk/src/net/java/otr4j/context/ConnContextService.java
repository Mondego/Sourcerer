package net.java.otr4j.context;

import net.java.otr4j.userstate.OtrlUserState;

public interface ConnContextService {
	/*
	 * Look up a connection context by name/account/protocol from the given
	 * OtrlUserState. If add_if_missing is true, allocate and return a new
	 * context if one does not currently exist. In that event, call
	 * add_app_data(data, context) so that app_data and app_data_free can be
	 * filled in by the application, and set *addedp to 1.
	 */
	ConnContext find(OtrlUserState us, String user, String accountname,
			String protocol, Boolean add_if_missing);

	/*
	 * Find a fingerprint in a given context, perhaps adding it if not present.
	 */
	Fingerprint findFingerprint(ConnContext context, byte[] fingerprint,
			Boolean add_if_missing);

	/* Set the trust level for a given fingerprint */
	void setTrust(Fingerprint fprint, String trust);

	/*
	 * Set the preshared secret for a given fingerprint. Note that this
	 * currently only stores the secret in the ConnContext structure, but
	 * doesn't yet do anything with it.
	 */
	void setPresharedSecret(ConnContext context, byte[] secret);

	/* Force a context into the OTRL_MSGSTATE_FINISHED state. */
	void forceFinished(ConnContext context);

	/* Force a context into the OTRL_MSGSTATE_PLAINTEXT state. */
	void forcePlaintext(ConnContext context);

	/*
	 * Forget a fingerprint (so long as it's not the active one. If it's a
	 * fingerprint_root, forget the whole context (as long as and_maybe_context
	 * is set, and it's PLAINTEXT). Also, if it's not the fingerprint_root, but
	 * it's the only fingerprint, and we're PLAINTEXT, forget the whole context
	 * if and_maybe_context is set.
	 */
	void contextForgetFingerprint(Fingerprint fprint, int and_maybe_context);

	/* Forget a whole context, so long as it's PLAINTEXT. */
	void contextForget(ConnContext context);

	/* Forget all the contexts in a given OtrlUserState. */
	void contextForgetAll(OtrlUserState us);
}

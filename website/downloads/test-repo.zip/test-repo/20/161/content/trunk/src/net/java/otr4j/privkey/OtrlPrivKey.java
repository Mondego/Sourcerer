package net.java.otr4j.privkey;

import java.security.KeyPair;

public class OtrlPrivKey {
	String accountname;
    String protocol;
    KeyPair keyPair;
}

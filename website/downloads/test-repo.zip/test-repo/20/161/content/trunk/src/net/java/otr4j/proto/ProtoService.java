package net.java.otr4j.proto;

import java.util.List;

import net.java.otr4j.context.ConnContext;
import net.java.otr4j.tlv.OtrlTLV;

public interface ProtoService {
	/*
	 * Return a pointer to a newly-allocated OTR query message, customized with
	 * our name. The caller should free() the result when he's done with it.
	 */
	String defaultQueryMsg(String ourname, OtrlPolicy policy);

	/*
	 * Return the best version of OTR support by both sides, given an OTR Query
	 * Message and the local policy.
	 */
	int queryBestvVersion(String querymsg, OtrlPolicy policy);

	/*
	 * Locate any whitespace tag in this message, and return the best version of
	 * OTR support on both sides. Set *starttagp and *endtagp to the start and
	 * end of the located tag, so that it can be snipped out.
	 */
	int whitespaceBestVersion(String msg, OtrlPolicy policy);

	/* Return the Message type of the given message. */
	OtrlMessageType messageType(String message);

	/*
	 * Create an OTR Data message. Pass the plaintext as msg, and an optional
	 * chain of TLVs. A newly-allocated string will be returned in *encmessagep.
	 */
	void createData(ConnContext context, String msg, List<OtrlTLV> tlvs);

	/* Extract the flags from an otherwise unreadable Data Message. */
	void dataReadFlags(String datamsg, byte[] flags);

	/*
	 * Accept an OTR Data Message in datamsg. Decrypt it and put the plaintext
	 * into *plaintextp, and any TLVs into tlvsp. Put any received flags into
	 * *flagsp (if non-NULL).
	 */
	void acceptData(String plaintextp, List<OtrlTLV> tlvsp,
			ConnContext context, String datamsg, String flagsp);

	/* Accumulate a potential fragment into the current context. */
	OtrlFragmentResult fragmentAccumulate(String unfragmessagep,
			ConnContext context, String msg);

	void fragmentCreate(int mms, int fragment_count, int fragments,
			String message);
}

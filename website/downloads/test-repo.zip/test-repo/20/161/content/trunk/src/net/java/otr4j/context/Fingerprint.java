package net.java.otr4j.context;

public class Fingerprint {

}

package net.java.otr4j.proto;

public enum OtrlFragmentResult {

}

package net.java.otr4j.privkey;

import java.security.PublicKey;

import net.java.otr4j.userstate.OtrlUserState;

public interface OtrlPrivKeyService {
	/* Convert a 20-byte hash value to a 45-byte human-readable value */
	String hashToHuman(byte[] hash);

	/* Calculate a human-readable hash of our DSA public key.  Return it in
	 * the passed fingerprint buffer.  Return NULL on error, or a pointer to
	 * the given buffer on success. */
	String fingerprint(OtrlUserState us, String accountname, String protocol);

	/* Calculate a raw hash of our DSA public key.  Return it in the passed
	 * fingerprint buffer.  Return NULL on error, or a pointer to the given
	 * buffer on success. */
	byte[] fingerprint_raw(OtrlUserState us, String accountname, String protocol);

	/* Read a sets of private DSA keys from a file on disk into the given
	 * OtrlUserState. */
	void read(OtrlUserState us, String filename);

	/* Generate a private DSA key for a given account, storing it into a
	 * file on disk, and loading it into the given OtrlUserState.  Overwrite any
	 * previously generated keys for that account in that OtrlUserState. */
	void generate(OtrlUserState us, String filename, String accountname, String protocol);

	/* Read the fingerprint store from a file on disk into the given
	 * OtrlUserState.  Use add_app_data to add application data to each
	 * ConnContext so created. */
	void readFingerprints(OtrlUserState us,String filename);

	/* Write the fingerprint store from a given OtrlUserState to a file on disk. */
	void writeFingerprints(OtrlUserState us, String filename);

	/* Fetch the private key from the given OtrlUserState associated with
	 * the given account */
	OtrlPrivKey find(OtrlUserState us, String accountname, String protocol);

	/* Forget a private key */
	void forget(OtrlPrivKey privatekey);

	/* Forget all private keys in a given OtrlUserState. */
	void forgetAll(OtrlUserState us);

	/* Sign data using a private key.  The data must be small enough to be
	 * signed (i.e. already hashed, if necessary).  The signature will be
	 * returned in *sigp, which the caller must free().  Its length will be
	 * returned in *siglenp. */
	void sign(OtrlPrivKey privkey, byte[] data);

	/* Verify a signature on data using a public key.  The data must be
	 * small enough to be signed (i.e. already hashed, if necessary). */
	void verify(PublicKey pub, byte[] data);
}

/**
 * The compatibility test suite for
 * <a href="http://code.google.com/p/atinject/">JSR-330: Dependency Injection
 * for Java</a>.
 *
 * @see org.atinject.tck.Tck
 */
package org.atinject.tck;

package example1;

import java.util.Arrays;
import java.util.List;

public class Example1 {

    public void LIXO(){

        List<String> players = null;

        String str = "";

        str.length();

        // Using lambda expression and functional operations
        //players.forEach((player) -> System.out.print(player + "; "));

        Comparator<String> comp = (first) -> Integer.compare(first, 18);

    }

}
